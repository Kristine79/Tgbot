# Telegram CryptoPayment Bot

Полнофункциональный Telegram-бот для приёма криптовалютных платежей через CryptoBot API с административной панелью.

## 🚀 Возможности

- 💰 **Приём платежей** в криптовалютах: USDT, BTC, ETH, USDC, TON, TRX
- 🔗 **Поддержка сетей**: TON, ETH, TRX, BEP20
- 📦 **Каталог товаров** с выбором продукта
- 📋 **История заказов** для каждого пользователя
- ⚙️ **Административная панель** с полной статистикой
- 🔔 **Уведомления** о платежах в реальном времени
- 🔄 **Вебхуки** для мгновенного подтверждения платежей
- 📊 **Отчёты** по продажам и пользователям

## 📋 Требования

- Python 3.10+
- Telegram Bot Token
- CryptoBot API Token
- SSL-сертификат (для вебхуков в продакшене)

## 🛠️ Установка

### 1. Клонирование и настройка

```bash
# Клонируйте репозиторий
git clone <repository_url>
cd crypto_payment_bot

# Создайте виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate  # Windows

# Установите зависимости
pip install -r requirements.txt
```

### 2. Настройка переменных окружения

Создайте файл `.env` в корневой директории:

```env
# Telegram Bot
BOT_TOKEN=your_telegram_bot_token_here
ADMIN_IDS=123456789,987654321
SUPPORT_USERNAME=your_support_username

# CryptoBot API
CRYPTOBOT_API_TOKEN=your_cryptobot_api_token_here
CRYPTOBOT_APP_ID=A511773

# Database
DB_PATH=payments.db

# Webhook (для продакшена)
WEBHOOK_HOST=https://your-domain.com
WEBHOOK_PATH=/webhook
WEBHOOK_SECRET=your_secret_key
LISTEN_HOST=0.0.0.0
LISTEN_PORT=8080
```

### 3. Получение токенов

#### Telegram Bot Token
1. Найдите @BotFather в Telegram
2. Отправьте `/newbot`
3. Следуйте инструкциям
4. Скопируйте токен

#### CryptoBot API Token
1. Откройте @CryptoBot в Telegram
2. Перейдите в Apps → Создать приложение
3. Скопируйте API токен
4. Запишите App ID (из URL приложения)

## 🚀 Запуск

### Режим разработки (polling)

```bash
python main.py
```

### Режим продакшена (webhook)

```bash
# Запуск веб-сервера
gunicorn webhook:app -b 0.0.0.0:8080 --workers=4

# Регистрация вебхука в CryptoBot
python webhook.py --setup
```

## 📁 Структура проекта

```
crypto_payment_bot/
├── main.py           # Основной файл бота
├── config.py         # Конфигурация приложения
├── database.py       # Работа с SQLite
├── cryptobot.py      # API CryptoBot
├── keyboards.py      # Клавиатуры бота
├── admin.py          # Административная панель
├── webhook.py        # Обработчик вебхуков
├── requirements.txt  # Зависимости
├── README.md         # Документация
└── .env              # Переменные окружения
```

## 📖 Использование

### Для пользователей

1. Запустите бота командой `/start`
2. Выберите товар из каталога
3. Выберите криптовалюту и сеть
4. Оплатите по ссылке или через CryptoBot
5. Нажмите "Проверить платёж"

### Для администраторов

После добавления вашего ID в `ADMIN_IDS`:

| Команда | Описание |
|---------|----------|
| `📊 Статистика` | Показать статистику продаж |
| `📋 Все заказы` | Список всех заказов |
| `⏳ Ожидающие` | Заказы в ожидании оплаты |
| `💰 Вывод` | Баланс приложения |
| `🔄 Проверка` | Принудительная проверка платежей |
| `🧹 Очистка` | Очистка базы данных |

## 🔧 API CryptoBot

### Поддерживаемые валюты

| Валюта | Сети |
|--------|------|
| USDT | TON, ETH, TRX, BEP20 |
| BTC | BTC |
| ETH | ETH |
| USDC | ETH, TRX |
| TON | TON |
| TRX | USDT |

### Методы API

```python
# Создание счёта
invoice = await cryptobot.create_invoice(
    amount=10.0,
    currency='USDT',
    description='Payment for order #123',
    network='TON'
)

# Проверка платежа
payment = await cryptobot.check_payment(invoice_id)
if payment.is_paid:
    print('Payment confirmed!')
```

## 📊 Административная панель

### Статистика

- Общее количество заказов
- Сумма полученных платежей
- Процент успешных платежей
- Средний чек
- Графики по дням/неделям

### Управление заказами

- Просмотр всех заказов
- Фильтрация по статусу
- Ручное подтверждение платежа
- Отмена заказов
- Детальная информация о каждом заказе

## 🔔 Вебхуки

### Настройка

1. Получите SSL-сертификат (Let's Encrypt)
2. Настройте домен и веб-сервер (nginx/Apache)
3. Зарегистрируйте вебхук:

```python
from webhook import register_webhook

success = register_webhook(
    bot_token=BOT_TOKEN,
    webhook_url='https://your-domain.com/webhook'
)
```

### Обработка событий

- `paid` - успешный платёж
- `expired` - истёк срок оплаты
- `cancelled` - отменённый платёж

## 🐛 Устранение неполадок

### Бот не отвечает

1. Проверьте токен бота
2. Убедитесь, что бот запущен
3. Проверьте логи на ошибки

### Платежи не создаются

1. Проверьте API токен CryptoBot
2. Убедитесь, что приложение активно
3. Проверьте баланс приложения

### Вебхуки не работают

1. Проверьте SSL-сертификат
2. Убедитесь, что порт открыт
3. Проверьте URL вебхука

## 📝 Лицензия

MIT License

## 🤝 Поддержка

По вопросам обращайтесь:
- Telegram: @your_support_username
- Email: support@example.com

---

Разработано с ❤️ для приёма криптовалютных платежей в Telegram
